import React from 'react'

export default function Other() {
  return (
    <main className="container" style={{ paddingTop: '5rem' }}>
      <div className="py-5">
        <h1 className="display-6 mb-3">Other Page</h1>
        <p className="lead">A simple page without the liquid glass sections.</p>
      </div>
    </main>
  )
}

